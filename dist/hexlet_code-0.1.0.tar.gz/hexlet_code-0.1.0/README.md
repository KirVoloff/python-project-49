### Hexlet tests and linter status:
[![Actions Status](https://github.com/KirVoloff/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KirVoloff/python-project-49/actions)

Ссылка на аккаунт Code_сlimate:
<a href="https://codeclimate.com/github/KirVoloff/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f7212c0c289a4616400b/maintainability" /></a>

ссылка на игру на чётность:
https://asciinema.org/a/1NJFo7D0N6mtLDydTd28EDAID
