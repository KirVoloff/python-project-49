# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['brain-games>=0.5.1,<0.6.0', 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/KirVoloff/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KirVoloff/python-project-49/actions)\n\nСсылка на аккаунт Code_сlimate:\n<a href="https://codeclimate.com/github/KirVoloff/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f7212c0c289a4616400b/maintainability" /></a>\n\nссылка на игру "Чётность/нечётность":\nhttps://asciinema.org/a/1NJFo7D0N6mtLDydTd28EDAID\n\nссылка на игру "Калькулятор":\nhttps://asciinema.org/a/yHqFwUvDBxVwac9yBLBJXZ3ZV\n\nссылка на игру "НОД":\nhttps://asciinema.org/a/NgmtVFvByqLpZBrf1933XfLy2\n',
    'author': "Vol'nov Kirill",
    'author_email': 'volnov-93@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.10,<4.0.0',
}


setup(**setup_kwargs)
