# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['brain-games>=0.5.1,<0.6.0', 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'package with 5 game',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/KirVoloff/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KirVoloff/python-project-49/actions)\n\n### Code_сlimate:\n<a href="https://codeclimate.com/github/KirVoloff/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f7212c0c289a4616400b/maintainability" /></a>\n\n### ссылка на игру "Чётность/нечётность":\n[![asciicast](https://asciinema.org/a/1NJFo7D0N6mtLDydTd28EDAID.svg)](https://asciinema.org/a/1NJFo7D0N6mtLDydTd28EDAID)\n\n### ссылка на игру "Калькулятор":\n[![asciicast](https://asciinema.org/a/yHqFwUvDBxVwac9yBLBJXZ3ZV.svg)](https://asciinema.org/a/yHqFwUvDBxVwac9yBLBJXZ3ZV)\n\n### ссылка на игру "НОД":\n[![asciicast](https://asciinema.org/a/NgmtVFvByqLpZBrf1933XfLy2.svg)](https://asciinema.org/a/NgmtVFvByqLpZBrf1933XfLy2)\n\n### ссылка на игру "Прогрессия":\n[![asciicast](https://asciinema.org/a/heI97S3eOosi5qVTGIleB4Cfa.svg)](https://asciinema.org/a/heI97S3eOosi5qVTGIleB4Cfa)\n\n### ссылка на игру "Простое ли число?":\n[![asciicast](https://asciinema.org/a/22Ig0MZjbJa1WC55d6cMysNsB.svg)](https://asciinema.org/a/22Ig0MZjbJa1WC55d6cMysNsB)\n\n\n\nОписание\nЭтот проект представляет собой небольшой развлекательный пакет из 5 консольных математических игр. Вы должны дать 3 правильных ответа на каждый тест, неправильный ответ прекращает игру.\n\n\nPython version:\n\n3.8.10\n\n\nPoetry version:\n\n0.1.0\n\n\nРуководство по установке.\nЧтобы установить пакет для конечного пользователя, выполните:\npython3 -m pip install --user dist/*.whl\n\nЕсли вы хотите установить его как разработчик. \nЧтобы установить все зависимости, выполните:\n\nmake install\n\nЧтобы собрать пакет, выполните:\n\nmake build\n\nДля установки пакета, выполните:\n\nmake package-install\n\n\nДля запуска игры:\n\nbrain-even\n\nУгадайте, является ли показанное число чётным.\n\n\nbrain-calc\n\nУгадайте результат простого математического выражения.\n\n\nbrain-gcd\n\nУгадайте наибольший общий делитель двух заданных чисел.\n\n\nbrain-progression\n\nУгадайте пропущенное число в заданной прогрессии.\n\n\nbrain-prime\n\nУгадайте, является данное число простым или нет.\n',
    'author': "Vol'nov Kirill",
    'author_email': 'volnov-93@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.10,<4.0.0',
}


setup(**setup_kwargs)
