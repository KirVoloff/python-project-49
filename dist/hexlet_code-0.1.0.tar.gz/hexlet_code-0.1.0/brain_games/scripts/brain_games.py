#!/usr/bin/env python3
import cli
cli.name()
