from cli import welcome_user
def function():
    x = welcome_user()
    print('Hello, "x"!')
